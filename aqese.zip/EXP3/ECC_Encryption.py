# Curve: y^2 = x^3 + ax + b (mod p); message must be a point on the curve
p, a = int(input("p: ")), int(input("a: "))
G = tuple(map(int, input("G (x y): ").split()))
M = tuple(map(int, input("Message point M (x y): ").split()))
d, k = int(input("private d: ")), int(input("k: "))

def add(P, Q):
    if P is None: return Q
    if Q is None: return P
    if P[0] == Q[0] and (P[1] + Q[1]) % p == 0: return None
    if P == Q: l = (3 * P[0] ** 2 + a) * pow(2 * P[1], -1, p) % p
    else: l = (Q[1] - P[1]) * pow(Q[0] - P[0], -1, p) % p
    x = (l * l - P[0] - Q[0]) % p
    return x, (l * (P[0] - x) - P[1]) % p

def mul(k, P):
    R = None
    while k:
        if k & 1: R = add(R, P)
        P = add(P, P)
        k >>= 1
    return R

Q = mul(d, G)
C1, C2 = mul(k, G), add(M, mul(k, Q))
print("public Q =", Q, "| C1 =", C1, "C2 =", C2)
S = mul(d, C1)
print("decrypted =", add(C2, (S[0], -S[1] % p)))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   p: 17
#   a: 2
#   G (x y): 5 1
#   Message point M (x y): 10 6
#   private d: 7
#   k: 10
# SAMPLE OUTPUT
#   public Q = (0, 6) | C1 = (7, 11) C2 = (10, 11)
#   decrypted = (10, 6)

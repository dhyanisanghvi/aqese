# Curve: y^2 = x^3 + ax + b (mod p)
p, a = int(input("p: ")), int(input("a: "))
G = tuple(map(int, input("G (x y): ").split()))
d, k = int(input("private d: ")), int(input("k: "))

def add(P, Q):
    if P is None: return Q
    if Q is None: return P
    if P[0] == Q[0] and (P[1] + Q[1]) % p == 0: return None
    if P == Q: l = (3 * P[0] ** 2 + a) * pow(2 * P[1], -1, p) % p
    else: l = (Q[1] - P[1]) * pow(Q[0] - P[0], -1, p) % p
    x = (l * l - P[0] - Q[0]) % p
    return x, (l * (P[0] - x) - P[1]) % p

def mul(k, P):
    R = None
    while k:
        if k & 1: R = add(R, P)
        P = add(P, P)
        k >>= 1
    return R

Q = mul(d, G)
print("Public Q = dG =", Q)
print("kG =", mul(k, G))
print("d(kG) =", mul(d, mul(k, G)), "k(dG) =", mul(k, Q))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   p: 17
#   a: 2
#   G (x y): 5 1
#   private d: 7
#   k: 10
# SAMPLE OUTPUT
#   Public Q = dG = (0, 6)
#   kG = (7, 11)
#   d(kG) = (16, 4) k(dG) = (16, 4)

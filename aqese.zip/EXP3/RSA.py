p, q, e, m = (int(input(s + ": ")) for s in ("p", "q", "e", "message"))
n, phi = p * q, (p - 1) * (q - 1)
d = pow(e, -1, phi)
c = pow(m, e, n)
print("n =", n, "phi =", phi, "d =", d)
print("cipher =", c, "plain =", pow(c, d, n))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   p: 61
#   q: 53
#   e: 17
#   message: 65
# SAMPLE OUTPUT
#   n = 3233 phi = 3120 d = 2753
#   cipher = 2790 plain = 65

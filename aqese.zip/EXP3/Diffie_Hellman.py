p, g, a, b = (int(input(s + ": ")) for s in ("p", "g", "Alice private a", "Bob private b"))
A, B = pow(g, a, p), pow(g, b, p)
print("A =", A, "B =", B)
print("Alice secret =", pow(B, a, p), "Bob secret =", pow(A, b, p))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   p: 23
#   g: 5
#   Alice private a: 6
#   Bob private b: 15
# SAMPLE OUTPUT
#   A = 8 B = 19
#   Alice secret = 2 Bob secret = 2

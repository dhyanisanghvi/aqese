p, g, x, k, m = (int(input(s + ": ")) for s in ("p", "g", "private x", "k", "message"))
y = pow(g, x, p)
c1, c2 = pow(g, k, p), m * pow(y, k, p) % p
print("y =", y, "c1 =", c1, "c2 =", c2)
print("plain =", c2 * pow(pow(c1, x, p), -1, p) % p)

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   p: 23
#   g: 5
#   private x: 6
#   k: 3
#   message: 10
# SAMPLE OUTPUT
#   y = 8 c1 = 10 c2 = 14
#   plain = 10

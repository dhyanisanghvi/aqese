# Curve: y^2 = x^3 + ax + b (mod p)
p, a = int(input("p: ")), int(input("a: "))
G = tuple(map(int, input("G (x y): ").split()))
n, d, k, z = (int(input(s + ": ")) for s in ("order n", "private d", "k", "hash"))

def add(P, Q):
    if P is None: return Q
    if Q is None: return P
    if P[0] == Q[0] and (P[1] + Q[1]) % p == 0: return None
    if P == Q: l = (3 * P[0] ** 2 + a) * pow(2 * P[1], -1, p) % p
    else: l = (Q[1] - P[1]) * pow(Q[0] - P[0], -1, p) % p
    x = (l * l - P[0] - Q[0]) % p
    return x, (l * (P[0] - x) - P[1]) % p

def mul(k, P):
    R = None
    while k:
        if k & 1: R = add(R, P)
        P = add(P, P)
        k >>= 1
    return R

Q = mul(d, G)
r = mul(k, G)[0] % n
s = pow(k, -1, n) * (z + r * d) % n
print("public Q =", Q, "signature =", (r, s))
z2 = int(input("hash to verify: "))
w = pow(s, -1, n)
P = add(mul(z2 * w % n, G), mul(r * w % n, Q))
print("valid" if P and P[0] % n == r else "invalid")

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   p: 17
#   a: 2
#   G (x y): 5 1
#   order n: 19
#   private d: 7
#   k: 10
#   hash: 5
#   hash to verify: 5
# SAMPLE OUTPUT
#   public Q = (0, 6) signature = (7, 13)
#   valid

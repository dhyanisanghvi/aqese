import hashlib, os
H = lambda b: hashlib.sha256(b).digest()
xor = lambda a, b: bytes(x ^ y for x, y in zip(a, b))

def mgf(seed, L):
    out, c = b"", 0
    while len(out) < L:
        out += H(seed + c.to_bytes(4, "big"))
        c += 1
    return out[:L]

p, q, e = 2**521 - 1, 2**607 - 1, 65537
n = p * q
d = pow(e, -1, (p - 1) * (q - 1))
emBits = n.bit_length() - 1
emLen = (emBits + 7) // 8
mask = 0xFF >> (8 * emLen - emBits)

def sign(m):
    salt = os.urandom(32)
    h = H(bytes(8) + H(m) + salt)
    db = bytes(emLen - 66) + b"\x01" + salt
    mdb = xor(db, mgf(h, len(db)))
    em = bytes([mdb[0] & mask]) + mdb[1:] + h + b"\xbc"
    return pow(int.from_bytes(em, "big"), d, n)

def verify(m, s):
    em = pow(s, e, n).to_bytes(emLen, "big")
    mdb, h = em[:emLen - 33], em[emLen - 33:-1]
    if em[-1] != 0xBC or mdb[0] & ~mask & 0xFF:
        return False
    db = xor(mdb, mgf(h, len(mdb)))
    db = bytes([db[0] & mask]) + db[1:]
    if db[:emLen - 66] != bytes(emLen - 66) or db[emLen - 66] != 1:
        return False
    return H(bytes(8) + H(m) + db[-32:]) == h

msg = input("Enter message: ").encode()
sig = sign(msg)
print("signature =", hex(sig)[:40] + "...")
print("valid:", verify(msg, sig))
print("tampered message:", verify(msg + b"x", sig))
print("tampered signature:", verify(msg, sig ^ 1))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Enter message: hello
# SAMPLE OUTPUT
#   signature = 0xb182a5d76f3add9160e7339cbfe231fbfc2911...
#   valid: True
#   tampered message: False
#   tampered signature: False
# (values may differ each run - random salt / k / keys)

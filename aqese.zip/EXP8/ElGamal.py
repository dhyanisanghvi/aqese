p, g, x, k, h = (int(input(s + ": ")) for s in ("p", "g", "private x", "k", "hash"))
y = pow(g, x, p)
r = pow(g, k, p)
s = (h - x * r) * pow(k, -1, p - 1) % (p - 1)
print("signature =", (r, s))
h2 = int(input("hash to verify: "))
print("valid" if pow(g, h2, p) == pow(y, r, p) * pow(r, s, p) % p else "invalid")

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   p: 23
#   g: 5
#   private x: 6
#   k: 5
#   hash: 10
#   hash to verify: 10
# SAMPLE OUTPUT
#   signature = (20, 0)
#   valid

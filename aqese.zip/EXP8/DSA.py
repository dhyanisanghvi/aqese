p, q, g, x, k, h = (int(input(s + ": ")) for s in ("p", "q", "g", "private x", "k", "hash"))
y = pow(g, x, p)
r = pow(g, k, p) % q
s = pow(k, -1, q) * (h + x * r) % q
print("signature =", (r, s))
h2 = int(input("hash to verify: "))
w = pow(s, -1, q)
v = pow(g, h2 * w % q, p) * pow(y, r * w % q, p) % p % q
print("valid" if v == r else "invalid")

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   p: 23
#   q: 11
#   g: 4
#   private x: 3
#   k: 7
#   hash: 10
#   hash to verify: 10
# SAMPLE OUTPUT
#   signature = (8, 8)
#   valid

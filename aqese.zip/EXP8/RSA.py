p, q, e = 104729, 1299709, 65537
n = p * q
d = pow(e, -1, (p - 1) * (q - 1))
M = 10**9 + 7

def h(m):
    x = 0
    for c in m.encode():
        x = (x * 257 + c) % M
    return x

msg = input("Enter message: ")
sig = pow(h(msg), d, n)
print("hash =", h(msg))
print("signature =", sig)

m2 = input("Enter message to verify: ")
s2 = int(input("Enter signature to verify: "))
print("VALID" if pow(s2, e, n) == h(m2) else "INVALID")

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Enter message: hello
#   Enter message to verify: hello
#   Enter signature to verify: 87962851123
# SAMPLE OUTPUT
#   hash = 418513571
#   signature = 87962851123
#   VALID

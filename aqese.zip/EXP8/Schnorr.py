p, q, g, x, k, h = (int(input(s + ": ")) for s in ("p", "q", "g", "private x", "k", "hash"))
y = pow(g, x, p)
r = pow(g, k, p)
e = (h + r) % q
s = (k + x * e) % q
print("signature =", (e, s))
h2 = int(input("hash to verify: "))
r2 = pow(g, s, p) * pow(y, -e, p) % p
print("valid" if (h2 + r2) % q == e else "invalid")

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   p: 23
#   q: 11
#   g: 4
#   private x: 3
#   k: 7
#   hash: 10
#   hash to verify: 10
# SAMPLE OUTPUT
#   signature = (7, 6)
#   valid

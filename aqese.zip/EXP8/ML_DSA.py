# Toy ML-DSA (Fiat-Shamir with aborts) - not compatible with FIPS 204
import random, hashlib
q, k, l, eta, tau = 8380417, 4, 4, 2, 1000
g1, g2 = 2**17, (q - 1) // 88
beta = tau * eta
R = random.randint
vec = lambda n, a: [R(-a, a) for _ in range(n)]
mv = lambda A, v: [sum(a * b for a, b in zip(row, v)) % q for row in A]
hb = lambda v: [(x + g2) // (2 * g2) for x in v]
H = lambda w1, m: int(hashlib.sha256(bytes(w1) + m).hexdigest(), 16) % (2 * tau + 1) - tau

A = [[R(0, q - 1) for _ in range(l)] for _ in range(k)]
s1, s2 = vec(l, eta), vec(k, eta)
t = [(a + b) % q for a, b in zip(mv(A, s1), s2)]

def sign(m):
    while True:
        y = vec(l, g1 - 1)
        w = mv(A, y)
        c = H(hb(w), m)
        z = [a + c * b for a, b in zip(y, s1)]
        r = [(a - c * b) % q for a, b in zip(w, s2)]
        if max(map(abs, z)) < g1 - beta and hb(r) == hb(w):
            return z, c

def verify(m, z, c):
    w = [(a - c * b) % q for a, b in zip(mv(A, z), t)]
    return max(map(abs, z)) < g1 - beta and H(hb(w), m) == c

msg = input("Enter message: ").encode()
z, c = sign(msg)
print("signature: c =", c, "z =", z[:2], "...")
print("valid:", verify(msg, z, c))
print("tampered message:", verify(msg + b"x", z, c))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Enter message: hello
# SAMPLE OUTPUT
#   signature: c = -647 z = [118599, 84490] ...
#   valid: True
#   tampered message: False
# (values may differ each run - random salt / k / keys)

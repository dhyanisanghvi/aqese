import random

p = 23
q = 11
g = 4

def hash_message(message):
    return sum(ord(ch) for ch in message)

def generate_keys(x):
    y = pow(g, x, p)
    return y

def sign(message, x):
    h = hash_message(message)

    while True:
        k = random.randint(1, q - 1)

        r = pow(g, k, p) % q
        if r == 0:
            continue

        s = (pow(k, -1, q) * (h + x*r)) % q
        if s != 0:
            return r, s

def verify(message, r, s, y):
    if not (0 < r < q and 0 < s < q):
        return False

    h = hash_message(message)

    w = pow(s, -1, q)
    u1 = (h * w) % q
    u2 = (r * w) % q

    v = ((pow(g, u1, p) * pow(y, u2, p)) % p) % q

    return v == r

x = int(input("Enter private key (1-10): "))
message = input("Enter message: ")

if not 0 < x < q:
    print("Invalid private key")
else:
    y = generate_keys(x)

    r, s = sign(message, x)
    valid = verify(message, r, s, y)

    print("\nPublic Key:", y)
    print("Private Key:", x)
    print("Signature:", (r, s))
    print("Verification:", "Valid" if valid else "Invalid")

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Enter private key (1-10): 5
#   Enter message: hello
# SAMPLE OUTPUT
#   Public Key: 12
#   Private Key: 5
#   Signature: (5, 9)
#   Verification: Valid
# (values may differ each run - random salt / k / keys)

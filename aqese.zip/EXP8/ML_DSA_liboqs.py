# ML-DSA-44 (FIPS 204) using the liboqs-python library
#
# Setup (Linux):
#   sudo apt update && sudo apt install -y python3 python3-venv git cmake ninja-build build-essential libssl-dev
#   python3 -m venv venv && source venv/bin/activate
#   pip install liboqs-python
# The first "import oqs" builds liboqs (takes a few minutes).
# libssl-dev is needed, otherwise the build stops with "Could NOT find OpenSSL".
#
# Expected for "hello": public key 1312 bytes, signature 2420 bytes,
# valid True, tampered message False.
import oqs

msg = input("Enter message: ").encode()
s = oqs.Signature("ML-DSA-44")
pk = s.generate_keypair()
sig = s.sign(msg)

print("public key:", len(pk), "bytes | signature:", len(sig), "bytes")
print("valid:", s.verify(msg, sig, pk))
print("tampered message:", s.verify(msg + b"x", sig, pk))


# --------------------------------------------------
# SAMPLE INPUT (type this when asked)
#   Enter message: hello
# (expected output is in the header comment)

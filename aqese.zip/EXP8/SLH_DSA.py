# Toy SLH-DSA (WOTS + Merkle tree) - not compatible with FIPS 205
import hashlib, os
H = lambda *a: hashlib.sha256(b"".join(a)).digest()[:16]
L, T = 35, 8
seed = os.urandom(16)

def digits(m):
    d = [int(c, 16) for c in H(m).hex()]
    s = sum(15 - x for x in d)
    return d + [s >> 8, (s >> 4) & 15, s & 15]

def chain(x, a, b):
    for _ in range(a, b):
        x = H(x)
    return x

sk = lambda i, j: H(seed, bytes([i, j]))
leaves = [H(*[chain(sk(i, j), 0, 15) for j in range(L)]) for i in range(T)]
tree = [leaves]
while len(tree[-1]) > 1:
    v = tree[-1]
    tree.append([H(v[i], v[i + 1]) for i in range(0, len(v), 2)])
root = tree[-1][0]

def sign(m, i):
    sig = [chain(sk(i, j), 0, d) for j, d in enumerate(digits(m))]
    path, n = [], i
    for lvl in tree[:-1]:
        path.append(lvl[n ^ 1])
        n >>= 1
    return sig, path

def verify(m, i, sig, path):
    x = H(*[chain(s, d, 15) for s, d in zip(sig, digits(m))])
    for p in path:
        x = H(x, p) if i % 2 == 0 else H(p, x)
        i >>= 1
    return x == root

msg = input("Enter message: ").encode()
i = 0
sig, path = sign(msg, i)
print("public key (root) =", root.hex())
print("valid:", verify(msg, i, sig, path))
print("tampered message:", verify(msg, i, sig, path) and verify(msg + b"x", i, sig, path))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Enter message: hello
# SAMPLE OUTPUT
#   public key (root) = b7026e2a2e4ce953bebad574eaeea88a
#   valid: True
#   tampered message: False
# (values may differ each run - random salt / k / keys)

t = input("Text: ").upper()
k = input("Key (26 letters): ").upper()
print("".join(k[ord(c) - 65] for c in t if c.isalpha()))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Text: HELLO
#   Key (26 letters): QWERTYUIOPASDFGHJKLZXCVBNM
# SAMPLE OUTPUT
#   ITSSG

t = input("Text: ").upper().replace(" ", "")
k = input("Key: ").upper()
mode = input("e/d: ")
K = len(k)
cols = sorted(range(K), key=lambda i: k[i])
if mode == "e":
    t += "X" * (-len(t) % K)
    print("".join(t[c::K] for c in cols))
else:
    n = len(t) // K
    out = [""] * len(t)
    for j, c in enumerate(cols):
        out[c::K] = t[j * n:(j + 1) * n]
    print("".join(out))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Text: WEAREDISCOVERED
#   Key: ZEBRAS
#   e/d: e
# SAMPLE OUTPUT
#   EVXACDESEROXDEXWIR

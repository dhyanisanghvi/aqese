t = "".join(c for c in input("Text: ").upper() if c.isalpha())
a, b, c, d = map(int, input("Key a b c d: ").split())
if len(t) % 2:
    t += "X"
r = ""
for i in range(0, len(t), 2):
    x, y = ord(t[i]) - 65, ord(t[i + 1]) - 65
    r += chr((a * x + b * y) % 26 + 65) + chr((c * x + d * y) % 26 + 65)
print(r)

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Text: HELP
#   Key a b c d: 3 3 2 5
# SAMPLE OUTPUT
#   HIAT

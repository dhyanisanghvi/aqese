k = input("Key: ").upper().replace("J", "I")
t = "".join(c for c in input("Text: ").upper() if c.isalpha()).replace("J", "I")
m = ""
for c in k + "ABCDEFGHIKLMNOPQRSTUVWXYZ":
    if c.isalpha() and c not in m:
        m += c
p, i = "", 0
while i < len(t):
    if i + 1 < len(t) and t[i] != t[i + 1]:
        p += t[i:i + 2]
        i += 2
    else:
        p += t[i] + "X"
        i += 1
r = ""
for i in range(0, len(p), 2):
    r1, c1 = divmod(m.index(p[i]), 5)
    r2, c2 = divmod(m.index(p[i + 1]), 5)
    if r1 == r2:
        c1, c2 = (c1 + 1) % 5, (c2 + 1) % 5
    elif c1 == c2:
        r1, r2 = (r1 + 1) % 5, (r2 + 1) % 5
    else:
        c1, c2 = c2, c1
    r += m[r1 * 5 + c1] + m[r2 * 5 + c2]
print(r)

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Key: MONARCHY
#   Text: INSTRUMENTS
# SAMPLE OUTPUT
#   GATLMZCLRQXA

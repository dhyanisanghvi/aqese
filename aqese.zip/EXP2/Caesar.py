t = input("Text: ").upper()
k = int(input("Key: "))
print("".join(chr((ord(c) - 65 + k) % 26 + 65) for c in t if c.isalpha()))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Text: HELLO
#   Key: 3
# SAMPLE OUTPUT
#   KHOOR

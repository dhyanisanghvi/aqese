t = input("Text: ").replace(" ", "")
k = int(input("Rails (2 or more): "))
mode = input("e/d: ")
pat, r, s = [], 0, 1
for _ in t:
    pat.append(r)
    if r == 0:
        s = 1
    elif r == k - 1:
        s = -1
    r += s
order = sorted(range(len(t)), key=lambda i: pat[i])
if mode == "e":
    print("".join(t[i] for i in order))
else:
    out = [""] * len(t)
    for ch, i in zip(t, order):
        out[i] = ch
    print("".join(out))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Text: WEAREDISCOVEREDFLEEATONCE
#   Rails (2 or more): 3
#   e/d: e
# SAMPLE OUTPUT
#   WECRLTEERDSOEEFEAOCAIVDEN

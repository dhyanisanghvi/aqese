t = input("Text: ")
k = input("Key (same length): ")
c = [ord(a) ^ ord(b) for a, b in zip(t, k)]
print("cipher =", c)
print("plain  =", "".join(chr(x ^ ord(b)) for x, b in zip(c, k)))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Text: HELLO
#   Key (same length): XMCKL
# SAMPLE OUTPUT
#   cipher = [16, 8, 15, 7, 3]
#   plain  = HELLO

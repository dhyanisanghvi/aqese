t = "".join(c for c in input("Text: ").upper() if c.isalpha())
k = input("Key: ").upper()
print("".join(chr((ord(c) + ord(k[i % len(k)]) - 130) % 26 + 65) for i, c in enumerate(t)))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Text: ATTACKATDAWN
#   Key: LEMON
# SAMPLE OUTPUT
#   LXFOPVEFRNHR

# Toy 8-bit block cipher: E(b, k) = (5b + k) mod 256
E = lambda b, k: (b * 5 + k) % 256
D = lambda c, k: (c - k) * 205 % 256
pt = [ord(c) for c in input("Plaintext: ")]
k, iv = int(input("Key (0-255): ")), int(input("IV (0-255): "))

ecb = [E(b, k) for b in pt]

cbc, p = [], iv
for b in pt:
    p = E(b ^ p, k)
    cbc.append(p)

cfb, p = [], iv
for b in pt:
    p = b ^ E(p, k)
    cfb.append(p)

ofb, p = [], iv
for b in pt:
    p = E(p, k)
    ofb.append(b ^ p)

ctr = [b ^ E((iv + i) % 256, k) for i, b in enumerate(pt)]

print("ECB:", ecb)
print("CBC:", cbc)
print("CFB:", cfb)
print("OFB:", ofb)
print("CTR:", ctr)
prev = [iv] + cbc[:-1]
print("CBC decrypted:", "".join(chr(D(c, k) ^ v) for c, v in zip(cbc, prev)))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Plaintext: HELLO
#   Key (0-255): 7
#   IV (0-255): 3
# SAMPLE OUTPUT
#   ECB: [111, 96, 131, 131, 146]
#   CBC: [126, 46, 241, 184, 218]
#   CFB: [94, 152, 179, 202, 182]
#   OFB: [94, 48, 28, 219, 181]
#   CTR: [94, 94, 108, 105, 101]
#   CBC decrypted: HELLO

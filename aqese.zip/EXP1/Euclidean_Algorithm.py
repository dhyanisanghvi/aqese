a, b = int(input("a: ")), int(input("b: "))
q, r = divmod(a, b)
print("division algorithm:", a, "=", b, "*", q, "+", r)

def egcd(a, b):
    if b == 0:
        return a, 1, 0
    g, x, y = egcd(b, a % b)
    return g, y, x - (a // b) * y

g, x, y = egcd(a, b)
print("gcd =", g, "| x, y =", x, y)
print("inverse of a mod b =", x % b if g == 1 else "none")

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   a: 17
#   b: 43
# SAMPLE OUTPUT
#   division algorithm: 17 = 43 * 0 + 17
#   gcd = 1 | x, y = -5 2
#   inverse of a mod b = 38

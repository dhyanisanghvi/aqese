B = (2, 3, 5, 7)

def euler(n):
    if n < 2: return False
    if n in B: return True
    if n % 2 == 0: return False
    return all(pow(a, (n - 1) // 2, n) in (1, n - 1) for a in B)

n = int(input("Enter number: "))
print("Euler:", "Prime" if euler(n) else "Composite")

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Enter number: 97
# SAMPLE OUTPUT
#   Euler: Prime

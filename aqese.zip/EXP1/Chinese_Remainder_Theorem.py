r = list(map(int, input("Remainders: ").split()))
m = list(map(int, input("Moduli: ").split()))
M = 1
for x in m:
    M *= x
x = sum(ri * (M // mi) * pow(M // mi, -1, mi) for ri, mi in zip(r, m)) % M
print("x =", x, "mod", M)

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Remainders: 2 3 2
#   Moduli: 3 5 7
# SAMPLE OUTPUT
#   x = 23 mod 105

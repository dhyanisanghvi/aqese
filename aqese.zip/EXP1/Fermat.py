B = (2, 3, 5, 7)

def fermat(n):
    if n < 2: return False
    if n in B: return True
    return all(pow(a, n - 1, n) == 1 for a in B)

n = int(input("Enter number: "))
print("Fermat:", "Prime" if fermat(n) else "Composite")

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Enter number: 97
# SAMPLE OUTPUT
#   Fermat: Prime

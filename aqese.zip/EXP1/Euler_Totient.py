n, a = int(input("n: ")), int(input("a: "))
phi, m, f = n, n, 2
while f * f <= m:
    if m % f == 0:
        while m % f == 0:
            m //= f
        phi -= phi // f
    f += 1
if m > 1:
    phi -= phi // m
print("phi(n) =", phi)
print("a^phi mod n =", pow(a, phi, n))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   n: 10
#   a: 3
# SAMPLE OUTPUT
#   phi(n) = 4
#   a^phi mod n = 1

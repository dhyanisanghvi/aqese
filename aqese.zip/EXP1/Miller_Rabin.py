B = (2, 3, 5, 7)

def miller_rabin(n):
    if n < 2: return False
    if n in B: return True
    if n % 2 == 0: return False
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for a in B:
        x = pow(a, d, n)
        if x in (1, n - 1): continue
        for _ in range(r - 1):
            x = x * x % n
            if x == n - 1: break
        else:
            return False
    return True

n = int(input("Enter number: "))
print("Miller-Rabin:", "Prime" if miller_rabin(n) else "Composite")

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   Enter number: 97
# SAMPLE OUTPUT
#   Miller-Rabin: Prime

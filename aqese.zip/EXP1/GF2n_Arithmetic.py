a, b = int(input("a (hex): "), 16), int(input("b (hex): "), 16)
poly = int(input("Modulus polynomial (hex, e.g. 11b): "), 16)
n = poly.bit_length() - 1

def mul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        b >>= 1
        a <<= 1
        if a >> n:
            a ^= poly
    return r

print("a * b =", hex(mul(a, b)))
print("inverse of a =", hex(next(x for x in range(1, 1 << n) if mul(a, x) == 1)))

# --------------------------------------------------
# SAMPLE INPUT (type these when asked)
#   a (hex): 57
#   b (hex): 83
#   Modulus polynomial (hex, e.g. 11b): 11b
# SAMPLE OUTPUT
#   a * b = 0xc1
#   inverse of a = 0xbf
